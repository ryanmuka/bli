# blabla
Untuk Desktop -> download -> langsung double-click file run.bat

Termux (Android) && Linux Ubuntu:
* `git clone https://github.com/mrsetset/blabla.git`
* `cd blabla`
* `php create.php` 

Update GIT Clone Repo Termux (Android) && Linux Ubuntu:
* `cd blabla`
* `git pull`

**Disclaimer:** Segala bentuk resiko atas tindakan ini saya pribadi tidak bertanggung jawab, gunakanlah senormal-nya!
